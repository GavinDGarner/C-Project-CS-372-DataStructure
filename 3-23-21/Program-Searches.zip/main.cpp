/*
Gavin Garner
CS 372
This program is an excercise in the speed of search algorithms like linear, binary, and interpolation.
*/
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <time.h>
#include <iomanip>
#include <bits/stdc++.h>

using namespace std;

ofstream outf;

//Constants
const int MAX = 10000;
const int RANGE = 65000;

//Functions
int randNum(int range){
  int number;
  number = (rand() % range) + 1;
  return number;
}

// for this function count is the i from fillArray
bool isUnique(int aray[], int target, int count){
  if(count == 0)
    return true;

  for(int i=0; i < count; i++){
    if(aray[i] == target)
      return false;
  }
  return true;
}

void fillArray(int aray[]){
  int rannum = 0;
  srand (time(NULL));
  for(int i=0; i < MAX; i++){
    rannum = randNum(RANGE);
    if(isUnique(aray, rannum, i)) // test if number is already in array b4 adding it in
      aray[i] = rannum;
    else{
      i--; // descrement so we can run again  
    }
  }
}

int searchLinearP(int aray[], int num){
  int probe = 0;
  for(int i=0; i < num; i++){
    probe++;
  }
  return probe;
}

int searchBinaryP(int aray[], int num){
  int probes = 0, low = 0, high = MAX-1;
  int mid = high/2;
  while(low < high){
    probes++;
    if(aray[mid] == num)
      return probes;
    else if(num > aray[mid]){
      low = mid + 1;
      mid = (high + low) / 2;
    }
    // else(num < aray[mid])
    else{
      high = mid - 1;
      mid = (high + low) / 2;
    }
  }
  if (low > high)
    return 0;
  
  return probes;
}

int searchInterpolation(int aray[], int num){
  int probes = 0, low = 1, high = MAX-1;  
  int inter = 0; 
  inter = (low) + (((num - aray[low])*(high - (low)))/(aray[high] - aray[low]));
  
  while(low < high){
    probes++;

    if(aray[inter] == num)
      return probes;

    else if(num > aray[inter]){
      low = inter + 1;
      inter = low + (((num - aray[low])*(high - low))/(aray[high] - aray[low]));
    }
    // else(num < aray[inter])
    else{
      high = inter - 1;
      inter = low + (((num - aray[low])*(high - low))/(aray[high] - aray[low]));
    }
  } 
  if (low > high)
    return 0;
  
  return probes;   
} 

int main() {
  outf.open("Result.txt");

  int pos = 0, probes = 0, avg = 0;
  int myaray[MAX];
  fillArray(myaray);

  // now lets find 3000 random numbers(1 to MAX) positions in this array and search for them with linear search

  outf << "After generating a list of 10,000 unique numbers, we amnt to know the effectiveness of three search algorithms by finding values within this list\n\n";
  outf << "First we will use a linear search. We start at the beginning and move 1 by 1 until we find our target.\nOn average, this process should use the formula -> {probes = (Number of Entries) / 2}. The Big O notation would be n/2. \nIn this case the average number of probes should be around 5,000.\nThe actual average number of probes is ";

  for(int i=0; i<3000; i++){
    pos = randNum(MAX);
    probes = probes + searchLinearP(myaray, pos);
  }
  avg = probes / 3000; // average number of probes needed to find the data
  outf << avg << "\n\n";

  //to set up the next 2 search algorithms, we need sorted data for them to work properly
  int k = sizeof(myaray) / sizeof(myaray[0]);
  sort(myaray, myaray + k);

  // Next with a binary search
  outf << "Next we will use a binary search which invloves starting from a point in the middle of the list and eliminating half the list each time we use a probe.\nWith this method we cut down the average probes significantly and the Big O notation would be {Log2 n} \n With this formula, the average number of probes should be around 13\nThe actual number of probes is ";

  probes = 0;
  for(int i=0; i<3000; i++){
    pos = randNum(MAX);
    probes = probes + searchBinaryP(myaray, myaray[pos]);
  }
  avg = probes / 3000;
  outf << avg << "\n\n";

  outf << "Now for the interpolation search method. This search algorith uses an enhanced formula to eliminate a great deal of list entries every time a probe is used. \nThe Big O for this would be {Log2(Log2 n)} making this an incredibly efficient search tool.\nWith this formula, the average number of probes should be around 3\nThe actual number of probees is ";

  probes = 0;
  for(int i=0; i<3000; i++){
    pos = randNum(MAX);
    probes = probes + searchInterpolation(myaray, myaray[pos]);
  }
  avg = probes / 3000;
  outf << avg << "\n\n";


  outf.close();
  return 0;
}